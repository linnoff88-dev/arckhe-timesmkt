import React from 'react';
import { Composition } from 'remotion';
import { ColdBrewAd } from './ColdBrewAd';
import { loadFont } from '@remotion/google-fonts/Inter';

// Pre-load the Inter font
loadFont();

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="ColdBrewAd"
        component={ColdBrewAd}
        durationInFrames={600} // 20 seconds at 30 fps
        fps={30}
        width={1080}
        height={1080}
      />
    </>
  );
};
