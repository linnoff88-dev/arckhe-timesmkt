# Cold Brew Coffee Co. — AI-Powered Social Media Content Automation

An AI-powered marketing pipeline that researches, generates, renders, and distributes social media content for a demo brand (**Cold Brew Coffee Co.**) using five coordinated AI agents.

> **For the full system architecture, agent responsibilities, pipeline output structure, and tech stack details, see [`CLAUDE.md`](CLAUDE.md).**

---

## Prerequisites

- **Node.js** v18+ (v20 LTS recommended)
- **npm** (comes with Node.js)
- **Playwright Chromium** (installed automatically — see step 3)

---

## Quick Start

### 1. Install Root Dependencies

From the project root:

```bash
npm install
```

### 2. Install Remotion Video Sub-Project Dependencies

```bash
cd remotion-ad
npm install
cd ..
```

### 3. Install Playwright Browser

Playwright is used by the Ad Creative Designer agent to render HTML ads to PNG. Install the Chromium browser binary:

```bash
npx playwright install chromium
```

### 4. Configure Environment Variables

Copy the example file and fill in your credentials:

```bash
cp .env.example .env
```

Then open `.env` and replace every `YOUR_*` placeholder with your actual keys. The `.env.example` file contains inline comments explaining where to get each key.

| Variable | Service | Purpose |
|---|---|---|
| `TAVILY_API_KEY` | [Tavily AI](https://tavily.com) | Market research web search |
| `YOUTUBE_API_KEY` | [Google Cloud Console](https://console.cloud.google.com) | YouTube public read operations |
| `YOUTUBE_CLIENT_ID` | Google Cloud Console → OAuth 2.0 | YouTube upload authentication |
| `YOUTUBE_CLIENT_SECRET` | Google Cloud Console → OAuth 2.0 | YouTube upload authentication |
| `YOUTUBE_REFRESH_TOKEN` | [Google OAuth 2.0 Playground](https://developers.google.com/oauthplayground) | Long-lived YouTube auth token |
| `INSTAGRAM_ACCOUNT_ID` | Meta Business Suite or Graph API | Instagram Professional Account ID |
| `INSTAGRAM_ACCESS_TOKEN` | [Graph API Explorer](https://developers.facebook.com/tools/explorer/) | Instagram publish token (Page Access Token) |
| `UPSTASH_REDIS_ENDPOINT` | [Upstash](https://upstash.com) | BullMQ job queue backend |
| `UPSTASH_REDIS_PASSWORD` | Upstash | Redis authentication |
| `SUPABASE_URL` | [Supabase](https://supabase.com) | Media file hosting |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase → Settings → API | Storage upload (server-side only) |

> **Note on YouTube Refresh Token:** Use the [Google OAuth 2.0 Playground](https://developers.google.com/oauthplayground). Click the gear icon → check "Use your own OAuth credentials" → paste your Client ID and Secret → authorize `https://www.googleapis.com/auth/youtube.upload` → exchange for tokens. The redirect URI `https://developers.google.com/oauthplayground` must be whitelisted in your Google Cloud OAuth Client settings.

> **Note on Instagram Access Token:** Use the [Graph API Explorer](https://developers.facebook.com/tools/explorer/). Select your app → select "Get Page Access Token" (not User Token) → grant `instagram_basic` and `instagram_content_publish` permissions → generate token. Verify your Account ID with `GET /me?fields=instagram_business_account`. All Graph API calls use `graph.facebook.com` (not `graph.instagram.com`).

---

## Running the Pipeline

### Full Pipeline (Research → Creative → Distribution)

Start the BullMQ worker in one terminal:

```bash
npm run pipeline:worker
```

Then trigger the orchestrator in another terminal:

```bash
npm run pipeline:run
```

Or with a custom JSON payload:

```bash
npm run pipeline:run:payload '{"task_name":"my_campaign","task_date":"2026-03-17","platform_targets":["instagram","youtube","threads"]}'
```

### Individual Components

| Command | What It Does |
|---|---|
| `node tavily-search.js` | Run a standalone Tavily market research search |
| `node supabase-upload.js` | Upload campaign media to Supabase storage |
| `node pipeline/publish_now.js` | Execute Instagram + YouTube publishing |
| `node render_ad_test.js` | Render an HTML ad to PNG via Playwright |

### Remotion Video Studio

To preview or edit video ads interactively:

```bash
cd remotion-ad
npm run dev
```

To render a video to MP4:

```bash
cd remotion-ad
npx remotion render src/index.ts ColdBrewAd ../outputs/<folder>/video/ad.mp4
```

---

## Project Structure

```
Cold Brew Coffee Co/
├── assets/                  # Brand images (product photos, backgrounds)
├── knowledge/               # Brand identity, platform guidelines, campaign briefs
├── skills/                  # AI agent skill definitions (6 agents)
│   ├── marketing-research-agent/
│   ├── ad-creative-designer/
│   ├── video-ad-specialist/
│   ├── copywriter-agent/
│   ├── distribution-agent/
│   └── orchestrator/
├── pipeline/                # BullMQ orchestrator, worker, and job payloads
│   ├── orchestrator.js
│   ├── worker.js
│   ├── publish_now.js
│   ├── redis.js
│   ├── queues.js
│   └── payloads/
├── remotion-ad/             # Remotion video sub-project (separate npm install)
│   ├── src/
│   ├── package.json
│   └── tsconfig.json
├── outputs/                 # Generated campaign outputs (research, ads, video, copy)
├── .env.example             # Environment variable template with setup instructions
├── CLAUDE.md                # Full system architecture documentation
├── package.json             # Root dependencies
└── README.md                # This file
```

---

## Outputs

The `outputs/` folder contains all generated campaign deliverables organized by task name and date. Each campaign folder includes:

- **Research**: `research_results.json`, `research_brief.md`, `interactive_report.html`
- **Ads**: `ads/instagram_ad.png`, `ads/layout.json`, `ads/ad.html`
- **Video**: `video/video_ad.mp4`
- **Copy**: `copy/instagram_caption.txt`, `copy/threads_post.txt`, `copy/youtube_metadata.json`
- **Distribution**: `media_urls.json`, `Publish <task_name> <date>.md`

> See [`CLAUDE.md`](CLAUDE.md) for the complete output folder structure and agent responsibilities.

---

## Supabase Setup

Ensure you have a Supabase project with:

1. A **storage bucket** named `campaign-uploads` set to **public**
2. The `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` configured in `.env`

The Service Role Key is used because the pipeline runs server-side with no user session — it bypasses RLS to upload files directly.

---

## Troubleshooting

| Issue | Fix |
|---|---|
| `npm install` fails | Ensure Node.js v18+ is installed |
| Playwright render fails | Run `npx playwright install chromium` |
| Instagram publish returns "Cannot parse access token" | Ensure you are using a **Page Access Token** (not User Token) from the Graph API Explorer, and that the API host is `graph.facebook.com` |
| YouTube upload returns 401 | Refresh Token may have expired; regenerate via the OAuth Playground. If your Google Cloud app is in "Testing" mode, tokens expire every 7 days |
| Supabase upload 404 | Confirm the `campaign-uploads` bucket exists and is set to public in the Supabase dashboard |
| Redis connection fails | Verify `UPSTASH_REDIS_ENDPOINT` uses the `rediss://` protocol (with double s for TLS) |
