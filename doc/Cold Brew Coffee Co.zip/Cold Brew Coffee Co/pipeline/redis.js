const fs = require('fs');
const path = require('path');

// Read a variable from .env manually — no dotenv dependency
function getEnvVar(key) {
  const envPath = path.resolve(__dirname, '../.env');
  const envData = fs.readFileSync(envPath, 'utf-8');
  const match = envData.match(new RegExp(`^${key}=(.*)`, 'm'));
  return match ? match[1].trim() : null;
}

// Upstash Redis connection config for BullMQ (ioredis-compatible format)
const redisConnection = {
  host: getEnvVar('UPSTASH_REDIS_ENDPOINT'),
  port: 6379,
  password: getEnvVar('UPSTASH_REDIS_PASSWORD'),
  tls: {},
};

module.exports = { redisConnection };
