/**
 * AI Content Pipeline Worker
 *
 * Processes jobs from the BullMQ queue. Each job maps to an agent handler.
 * Handlers are stubs — replace with real agent execution logic or Claude API calls.
 *
 * Usage:
 *   node pipeline/worker.js
 */

const { Worker } = require('bullmq');
const { redisConnection } = require('./redis');
const { QUEUE_NAME } = require('./queues');
const fs = require('fs');
const path = require('path');

// ── Agent Handlers ─────────────────────────────────────────────────────────────

async function handleResearchAgent(job) {
  const { task_name, task_date, output_dir } = job.data;
  console.log(`  [research_agent] Running for task: ${task_name}`);

  // Ensure output directory exists
  fs.mkdirSync(path.resolve(output_dir), { recursive: true });

  // TODO: Invoke Marketing Research Agent via Claude API or CLI
  // Expected output: outputs/<task_name>_<date>/research_results.json
  log(output_dir, 'research_agent', 'Research Agent completed. Outputs saved to output_dir.');
  return { status: 'complete', output: `${output_dir}/research_results.json` };
}

async function handleAdCreativeDesigner(job) {
  const { task_name, task_date, output_dir } = job.data;
  console.log(`  [ad_creative_designer] Running for task: ${task_name}`);

  fs.mkdirSync(path.resolve(`${output_dir}/ads`), { recursive: true });

  // TODO: Invoke Ad Creative Designer via Claude API or CLI
  // Expected output: outputs/<task_name>_<date>/ads/layout.json
  log(output_dir, 'ad_creative_designer', 'Ad Creative Designer completed.');
  return { status: 'complete', output: `${output_dir}/ads/layout.json` };
}

async function handleVideoAdSpecialist(job) {
  const { task_name, task_date, output_dir } = job.data;
  console.log(`  [video_ad_specialist] Running for task: ${task_name}`);

  fs.mkdirSync(path.resolve(`${output_dir}/video`), { recursive: true });

  // TODO: Invoke Video Ad Specialist + Remotion render via CLI
  // Expected output: outputs/<task_name>_<date>/video/ad.mp4
  log(output_dir, 'video_ad_specialist', 'Video Ad Specialist completed.');
  return { status: 'complete', output: `${output_dir}/video/ad.mp4` };
}

async function handleCopywriterAgent(job) {
  const { task_name, task_date, output_dir } = job.data;
  console.log(`  [copywriter_agent] Running for task: ${task_name}`);

  fs.mkdirSync(path.resolve(`${output_dir}/copy`), { recursive: true });

  // TODO: Invoke Copywriter Agent via Claude API or CLI
  // Expected outputs:
  //   outputs/<task_name>_<date>/copy/instagram_caption.txt
  //   outputs/<task_name>_<date>/copy/threads_post.txt
  //   outputs/<task_name>_<date>/copy/youtube_metadata.json
  log(output_dir, 'copywriter_agent', 'Copywriter Agent completed.');
  return { status: 'complete', output: `${output_dir}/copy/` };
}

async function handleDistributionAgent(job) {
  const { task_name, task_date, output_dir } = job.data;
  console.log(`  [distribution_agent] Running for task: ${task_name}`);

  // TODO: Invoke Distribution Agent via Claude API or CLI
  // Expected output: outputs/<task_name>_<date>/Publish <task_name> <date>.md
  log(output_dir, 'distribution_agent', 'Distribution Agent completed. Publish MD generated.');
  return { status: 'complete', output: `${output_dir}/Publish ${task_name} ${task_date}.md` };
}

// ── Handler registry ────────────────────────────────────────────────────────────

const HANDLERS = {
  research_agent: handleResearchAgent,
  ad_creative_designer: handleAdCreativeDesigner,
  video_ad_specialist: handleVideoAdSpecialist,
  copywriter_agent: handleCopywriterAgent,
  distribution_agent: handleDistributionAgent,
};

// ── Logger ────────────────────────────────────────────────────────────────────

function log(outputDir, agentName, message) {
  const logDir = path.resolve(outputDir, 'logs');
  fs.mkdirSync(logDir, { recursive: true });
  const logFile = path.join(logDir, `${agentName}.log`);
  const entry = `[${new Date().toISOString()}] ${message}\n`;
  fs.appendFileSync(logFile, entry);
  console.log(`  [${agentName}] ${message}`);
}

// ── Worker ────────────────────────────────────────────────────────────────────

const worker = new Worker(
  QUEUE_NAME,
  async (job) => {
    const agentName = job.data.agent;
    const handler = HANDLERS[agentName];

    if (!handler) {
      throw new Error(`No handler registered for agent: ${agentName}`);
    }

    await job.updateProgress(0);
    const result = await handler(job);
    await job.updateProgress(100);

    return result;
  },
  {
    connection: redisConnection,
    concurrency: 3, // Allow up to 3 jobs to run in parallel (e.g., video + image + copy after research)
  }
);

// ── Event listeners ───────────────────────────────────────────────────────────

worker.on('completed', (job, result) => {
  console.log(`\n✅ Job completed: ${job.data.agent} (ID: ${job.id})`);
  console.log(`   Output: ${result?.output || 'n/a'}`);
});

worker.on('failed', (job, err) => {
  console.error(`\n❌ Job failed: ${job?.data?.agent} (ID: ${job?.id})`);
  console.error(`   Error: ${err.message}`);
  if (job?.data?.output_dir) {
    const logDir = path.resolve(job.data.output_dir, 'logs');
    fs.mkdirSync(logDir, { recursive: true });
    const logFile = path.join(logDir, `${job.data.agent}_error.log`);
    fs.appendFileSync(logFile, `[${new Date().toISOString()}] FAILED: ${err.message}\n`);
  }
});

worker.on('progress', (job, progress) => {
  console.log(`  ⏳ ${job.data.agent} — ${progress}% complete`);
});

console.log(`\n🔄 Worker started — listening on queue: "${QUEUE_NAME}"`);
console.log('   Press Ctrl+C to stop.\n');
